#include <iostream>
#include <vector>
#include <sstream>
#include <list>
#include <limits.h>
using namespace std;

class Dictionary{

private:
	int vertex;
    vector<string> wordSet;
    vector<int> adList[1000];
	vector<int> distance;
	vector<int> behind;
	vector<int> path;
	int origin;
	int destination;
	list<int> location;
	vector<int> counter;
public:
    Dictionary(){ origin = 5 ; destination = 10;};
    void getDictionarywordSet() ;
    void adList_list();
    void display();
	bool BFS_traversal();
	int listSize();
	int sizeTheArray(vector<int> adList[]);
	void shortdist();
};

int Dictionary::listSize(){return wordSet.size();}
void Dictionary::display(){
/*
 for (size_t v = path.size()-2; v >=0; v--){
    if(v > 0)
        cout<< wordSet.at(path[v])<<"->";
    else
     cout<< wordSet.at(path[v]);
 }
*/

    for (int i = path.size() - 1; i >= 0; i--){
        if(i !=0) cout << wordSet.at(path[i])<<" -> ";
        else cout << wordSet.at(path[i]);
    }

}

bool Dictionary::BFS_traversal(){
    list<int>location;
   int v = wordSet.size();
    bool visited[v];
    for (int i = 0; i < v; i++) {
        int x = -1;
        behind.push_back(-1);
        distance.push_back(INT_MAX);
        int P = -1;
        int L = -1;
        visited[i] = false;
    }

    visited[origin] = true;
    distance.at(origin) = 0;
    location.push_back(origin);
    while (!location.empty()) {
        int u = location.front();
        location.pop_front();
        for (size_t  i = 0; i < adList[u].size(); i++) {
            if (visited[adList[u][i]] == false) {

                visited[adList[u][i]] = true;

                distance[adList[u][i]] = distance[u] + 1;

                behind[adList[u][i]] = u;

                location.push_back(adList[u][i]);

                if (adList[u][i] == destination)
                   return true;
            }
        }
    }

    return false;

}



void Dictionary::shortdist(){
    int n = destination;
    path.push_back(n);
    while (behind[n] != -1) {
        path.push_back(behind[n]);
        n = behind[n];
    }
}

void Dictionary::getDictionarywordSet(){
     string word;
     cin>>word;

     string ori;
     string dest;
     int monitor = 0;




     for(size_t i = 0; i < word.size(); i++){
        if(!isalpha(word.at(i)))
            monitor = 100;
        else if(monitor ==0)
            ori+=word.at(i) ;
        else if(monitor == 100)
            dest+=word.at(i);
     }

    while(true){
    cin>>word;
    if(word == "-1")
    break;
    wordSet.push_back(word);
    }

     /*for(int i = 0; i < word.size(); i++){
        cout<<wordSet.at(i) << " ";
     }*/
      for(size_t i = 0; i < wordSet.size(); i++){
        if(wordSet.at(i) ==  ori)
            origin =i;
        if(wordSet.at(i) ==  dest)
            destination =i;
     }

}

void Dictionary::adList_list(){
string temp;
string follow;
int dist = 0;

for(size_t i = 0 ; i < wordSet.size()-1; i++){
        temp = wordSet.at(i);
    for(size_t j = i+1 ; j < wordSet.size() ; j++){
        follow = wordSet.at(j);
        for(size_t w = 0 ; w < temp.size(); w++){
            if(follow.at(w) != temp.at(w))
                dist++;
        }
         if(dist == 1){
                adList[j].push_back(i);
                adList[i].push_back(j);
            }
        dist = 0;
    }

}
}

int main(){

    Dictionary dict;
    dict.getDictionarywordSet();
  // vector<int> adList[dict.listSize()+1];
    dict.adList_list();
    if (dict.BFS_traversal() == false) return 0;
    else dict.shortdist();
    dict.display();
    return 0;
}
